# PureCam Starter

PureCam 是一个无广告、无账号、无厂商云依赖的 Android RTSP 播放器起步项目。

## 当前版本包含
- 手动填写摄像头 IP/主机名、RTSP 端口、用户名、密码、视频流路径
- Media3 RTSP 实时视频播放
- 播放状态与错误提示
- 不含广告、统计分析或厂商云 SDK
- 暂不保存摄像头密码；当前仅在本次运行中使用

## 技术栈
- Kotlin
- Android Gradle Plugin 8.13.2
- Gradle 8.13
- JDK 17
- Android compileSdk 36 / minSdk 23
- AndroidX Media3 1.11.1

## 云端构建
本项目为 GitHub Actions 准备了工作流模板 `build.yml.template`。
将它复制到仓库中的 `.github/workflows/android.yml`，推送代码后会自动构建 Debug APK。

构建产物路径：
`app/build/outputs/apk/debug/app-debug.apk`

## 重要说明
1. 摄像头必须支持 RTSP。仅支持厂商私有协议/云连接的设备不能直接使用本客户端。
2. RTSP 路径因品牌、型号和固件而异，`/stream1` 只是示例。
3. Media3 RTSP 支持 H.264、AAC、AC3，以及 UDP 单播和 RTP over RTSP/TCP；并非所有摄像头编码都兼容。
4. 当前版本是连接验证用 MVP，不包含 ONVIF 自动发现、录像、截图、加密凭据存储或远程 VPN。
5. 不要把真实摄像头密码、RTSP URL 或带凭据的日志公开到 GitHub。
6. 公开仓库中的代码是公开可见的。仓库不包含任何真实摄像头资料。

## 后续计划
- ONVIF 设备发现和媒体配置
- 本地加密保存摄像头配置
- 截图和本地录像
- 多摄像头列表
- WireGuard VPN 远程访问说明
