package com.purecam.app

import android.app.Activity
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : Activity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView
    private lateinit var hostInput: EditText
    private lateinit var portInput: EditText
    private lateinit var userInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var pathInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(15, 23, 42)
        window.navigationBarColor = Color.BLACK
        buildScreen()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(Color.rgb(248, 250, 252))
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)

        val title = TextView(this).apply {
            text = "PureCam"
            textSize = 28f
            setTextColor(Color.rgb(15, 23, 42))
            gravity = Gravity.CENTER_VERTICAL
        }
        content.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "纯净 · 本地连接 · 无广告"
            textSize = 14f
            setTextColor(Color.rgb(100, 116, 139))
        }
        content.addView(subtitle, matchWrap())

        playerView = PlayerView(this).apply {
            useController = true
            setBackgroundColor(Color.BLACK)
        }
        val videoParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(220)
        ).apply { topMargin = dp(16); bottomMargin = dp(12) }
        content.addView(playerView, videoParams)

        status = TextView(this).apply {
            text = "尚未连接。请填写摄像头信息。"
            textSize = 13f
            setTextColor(Color.rgb(71, 85, 105))
            setPadding(0, dp(4), 0, dp(12))
        }
        content.addView(status, matchWrap())

        hostInput = field("摄像头 IP 或主机名，例如 192.168.1.100")
        portInput = field("RTSP 端口", "554", InputType.TYPE_CLASS_NUMBER)
        userInput = field("用户名（可留空）")
        passwordInput = field("密码（可留空）", password = true)
        pathInput = field("视频流路径，例如 /stream1", "/stream1")

        content.addView(label("摄像头地址"))
        content.addView(hostInput, fieldParams())
        content.addView(label("端口"))
        content.addView(portInput, fieldParams())
        content.addView(label("用户名"))
        content.addView(userInput, fieldParams())
        content.addView(label("密码"))
        content.addView(passwordInput, fieldParams())
        content.addView(label("视频流路径"))
        content.addView(pathInput, fieldParams())

        val connect = Button(this).apply {
            text = "连接并播放"
            setOnClickListener { connectCamera() }
        }
        val connectParams = matchWrap().apply { topMargin = dp(12) }
        content.addView(connect, connectParams)

        val stop = Button(this).apply {
            text = "停止播放"
            setOnClickListener {
                player?.stop()
                status.text = "已停止播放。"
            }
        }
        content.addView(stop, matchWrap())

        val note = TextView(this).apply {
            text = "提示：摄像头必须支持 RTSP，并且手机与摄像头需要处于可互相访问的网络中。不同品牌的 RTSP 路径可能不同。此测试版不会把摄像头资料上传到服务器，也暂不保存密码。"
            textSize = 12f
            setTextColor(Color.rgb(100, 116, 139))
            setPadding(0, dp(12), 0, dp(20))
        }
        content.addView(note, matchWrap())

        page.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(page)
    }

    private fun connectCamera() {
        val host = hostInput.text.toString().trim()
        val port = portInput.text.toString().trim().toIntOrNull()
        val username = userInput.text.toString()
        val password = passwordInput.text.toString()
        var path = pathInput.text.toString().trim()

        if (host.isBlank()) {
            status.text = "请输入摄像头 IP 地址或主机名。"
            return
        }
        if (port == null || port !in 1..65535) {
            status.text = "端口必须是 1 到 65535 之间的数字。"
            return
        }
        if (path.isBlank()) path = "/"
        if (!path.startsWith("/")) path = "/$path"

        val credentials = if (username.isNotEmpty() || password.isNotEmpty()) {
            "${Uri.encode(username)}:${Uri.encode(password)}@"
        } else ""
        val encodedPath = Uri.encode(path, "/")
        val rtspUrl = "rtsp://$credentials$host:$port$encodedPath"

        try {
            player?.release()
            player = ExoPlayer.Builder(this).build().also { exo ->
                playerView.player = exo
                exo.addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        status.text = when (playbackState) {
                            Player.STATE_BUFFERING -> "正在连接摄像头并缓冲视频…"
                            Player.STATE_READY -> "已连接，正在播放。"
                            Player.STATE_ENDED -> "视频流已结束。"
                            else -> "正在等待视频流…"
                        }
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        status.text = "播放失败：${error.errorCodeName}。请检查 IP、端口、账号密码和 RTSP 路径。"
                    }
                })
                exo.setMediaItem(MediaItem.fromUri(rtspUrl))
                exo.prepare()
                exo.playWhenReady = true
            }
            status.text = "正在连接：$host:$port$path"
        } catch (e: Exception) {
            status.text = "连接初始化失败：${e.message ?: "未知错误"}"
        }
    }

    private fun field(
        hintText: String,
        initial: String = "",
        inputType: Int = InputType.TYPE_CLASS_TEXT,
        password: Boolean = false
    ) = EditText(this).apply {
        hint = hintText
        setText(initial)
        textSize = 14f
        setSingleLine(true)
        this.inputType = if (password) {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        } else inputType
        setPadding(dp(12), dp(10), dp(12), dp(10))
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 13f
        setTextColor(Color.rgb(51, 65, 85))
        setPadding(0, dp(8), 0, dp(3))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun fieldParams() = matchWrap().apply {
        bottomMargin = dp(3)
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        playerView.player = null
        player?.release()
        player = null
        super.onDestroy()
    }
}
